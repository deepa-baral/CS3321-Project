﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "admin" And txtPassword.Text = "password" Then
            Call adminLogin()
        ElseIf txtUsername.Text = "admin2" And txtPassword.Text = "password" Then
            Call adminLogin()
        ElseIf txtUsername.Text = "user" And txtPassword.Text = "password" Then
            Call userlogin()
        Else
            MsgBox("Incorrect username and Password!")
        End If
    End Sub
    Private Sub adminlogin()
        frmMain.Text = "MAin Form ---Welcoe" & txtUsername.Text
        frmMain.lblMessage.Text = "Welcome Admin!"
        frmMain.Show()
        Me.Close()
    End Sub
    Private Sub userlogin()
        frmMain.Text = "MAin Form---- Welcome" & txtUsername.Text
        frmMain.lblMessage.Text = "Welcome Admin!"
        frmMain.Show()
        Me.Close()
    End Sub
End Class
